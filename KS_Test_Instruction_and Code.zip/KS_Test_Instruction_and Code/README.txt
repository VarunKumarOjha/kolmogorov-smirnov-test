For Windows
Please open the file name "KSTestRun.txt" and Save it as "KSTestRun.bat"

Once bat file is created we just need to run this file.
The program will be running.
We just need to give two file name as input.
Please follow the instructionin the picture
KS_Test_Example.png to use this code.

Two example of input files are given here
X = "BP.txt"
Y = "CG.txt"

So the KST test will be conducted in between these two samples.