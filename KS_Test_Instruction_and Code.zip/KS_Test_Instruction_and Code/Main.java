/**** @author Varun Kumar Ojha*/
import java.io.*;
import java.math.*;
class KSTest
{
 void kst(double num1[],double num2[])
 {
   int n = num1.length;
   int m = num2.length;
  
   double num[] = new double[n+m];
   
   for (int i = 0; i < n+m; i++)
   {
     if(i < n)
      num[i] = num1[i];
     else
      num[i] = num2[i-n]; 

     //System.out.println(num[i]); 
   }
   
   //System.out.println(num.length);
   
   for (int i = 0; i < num.length; i++)
   {
     for (int j = i + 1; j < num.length; j++)
     {
       if (num[i] > num[j])
       {
         double temp;
         temp = num[i];
         num[i] = num[j];
	 num[j] = temp;
       }
     }
   }
 

   double Lmax = -(n+m);
   double Smax = -(n+m); 
   double Dmax = 0;

  /*System.out.println("O");
  for (int j = 0; j < n+m; j++)
  {
       System.out.print(" "+num[j]);
  }
  
  System.out.println("x");
  for (int j = 0; j < n; j++)
  {
       System.out.print(" "+num1[j]);
  }
  System.out.println("y");
  for (int j = 0; j < n; j++)
  {
       System.out.print(" "+num2[j]);
  }
  System.out.println();*/

   for (int i = 0; i < n+m; i++)
   {
     
     int x=0,y=0; 
     
     for (int j = 0; j < n; j++)
     {
       if(num1[j]<num[i])
         x = x+1; 
      
     }
     //System.out.print(" x:"+x); 

     for (int j = 0; j < m; j++)
     {
       if(num2[j]<num[i])
         y = y+1; 
     }
     //System.out.print(" y:"+y);
 
     double ltemp=0,stemp=0,dtemp=0;

     ltemp = ((double)x/(double)n - (double)y/(double)m);
     stemp = ((double)y/(double)n - (double)x/(double)m);
     dtemp = Math.abs(((double)x/(double)n - (double)y/(double)m));
     
     //System.out.printf("  %.3f   %.3f    %.3f\n",ltemp,stemp,stemp);

     if(ltemp > Lmax)
        Lmax = ltemp; 

     if(stemp > Smax)
        Smax = stemp;

     if(dtemp > Dmax)
        Dmax = dtemp; 
     //System.out.println();     
   }
   
   System.out.printf("Lmax: %.3f Smax: %.3f Dmax: %.3f\n",Lmax,Smax,Dmax);
  
   double Dpls, Dmins, D;
   //double calpha = 1.22;// for a = 0.10 i.e. for 90% confidence
   double calpha = 1.36;// for a = 0.05 i.e. for 95% confidence
   //double calpha = 1.63;// for a = 0.01 i.e. for 99% confidence
  
   
   D = calpha*Math.sqrt((double)(n+m)/(double)(n*m)); 

   System.out.printf("D: %.3f \n",D);   
   
   Dpls=Dmins=D; 
  
   if(Lmax>Dpls)
     System.out.println("X is stochastically larger than Y");
   else if(Smax>Dmins)
     System.out.println("X is stochastically smaller than Y");  
   else if(Dmax>D)
     System.out.println("X and Y are from different distribution");
   else
     System.out.println("X and Y are indistingusable i.e null hypothisis accepted");
  
 }
}

public class Main
{
 public static void main(String[] args) throws IOException
 {
   try{
 
   BufferedReader ibr = new BufferedReader(new InputStreamReader(System.in));

   System.out.print("\nEnter First File Name:");
   String FILE_X1=ibr.readLine();
   //FILE_X1 = FILE_X1+".txt";
   String X1 = FILE_X1;//"BP.txt";

   FileReader  fr = new FileReader(X1);
   BufferedReader br =  new BufferedReader(fr);

   //System.out.println("Enter Cardinality of 1st Sample: ");

   int n = 0;//Integer.parseInt(br.readLine());
   while(br.readLine() != null)
     n++;
  
   System.out.println("File X is of Size: "+n);  

   double a[] = new double[n];
  
   br.close();
   fr.close();

   FileReader  frx = new FileReader(X1);
   BufferedReader brx =  new BufferedReader(frx);
 
   //System.out.println("Enter numbers : ");
   for (int i = 0; i < n; i++)
   {
    a[i] = Double.parseDouble(brx.readLine());
    //System.out.printf(" %.3f",a[i]);
   }
   
   System.out.print("\nEnter First File Name:");
   String FILE_X2=ibr.readLine();
   //FILE_X2 = FILE_X2+".txt";
   String X2 = FILE_X2;//"CG.txt";

   FileReader  fr1 = new FileReader(X2);
   BufferedReader br1 =  new BufferedReader(fr1);

   //System.out.println("Enter Cardinality of 2st Sample: ");
   
   int m = 0;//Integer.parseInt(br.readLine());
   while(br1.readLine() != null)
     m++;
  
   System.out.println("File Y is of Size: "+m); 
 
   double b[] = new double[m];
  
   br1.close();
   fr1.close();

   //br.mark(10);
   //br.reset();

   FileReader  fry = new FileReader(X2);
   BufferedReader bry =  new BufferedReader(fry);

   //System.out.println("Enter numbers : ");
   for (int i = 0; i < m; i++)
   {
    b[i] = Double.parseDouble(bry.readLine());
    //System.out.printf(" %.3f",b[i]);
   }

   //double da;
   //System.out.println("Enter critcal value : ");
   //da = Double.parseDouble(ibr.readLine());
  
   KSTest ks = new KSTest();
   ks.kst(a,b);

   }
   catch(Exception e)
   {
      System.out.println(e);
   }

  }
}
